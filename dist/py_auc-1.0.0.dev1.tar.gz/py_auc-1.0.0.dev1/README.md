# py_auc
library for calculating the area under the curve (ROC, PR) of binary classifiers
